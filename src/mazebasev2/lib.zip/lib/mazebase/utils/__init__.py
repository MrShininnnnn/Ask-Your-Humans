from .mazeutils import MazeException
